// 23 august 2012
package main

import (
	"fmt"
	"strings"
	"bytes"
	"database/sql"
	_ "github.com/ziutek/mymysql/godrv"
//	_ "github.com/Go-SQL-Driver/MySQL"
	"github.com/jmoiron/sqlx"
	"log"
	"sort"
	"unicode"
)

type SQL struct {
	db			*sqlx.DB
	getconsoles	*sql.Stmt
	getgames		*sql.Stmt
	getredirect	*sql.Stmt
	getcatlist		*sql.Stmt
	db_scanbox	*sqlx.DB		// TODO do I need a separate one?
//	getscanboxes	*sqlx.Stmt
	getscanboxes	*sql.Stmt		// sqlx doesn't fill in the structure properly?
	getnoscans	*sql.Stmt
}

var globsql *SQL

func opendb(which string) (*sqlx.DB, error) {
	return sqlx.Open("mymysql",
		"tcp:" + config.DBServer + "*" +
			which + "/" + config.DBUsername + "/" + config.DBPassword)
// for Go-SQL-Driver:
//	return sqlx.Open("mysql",
//		config.DBUsername + ":" + config.DBPassword + "@" +
//			"tcp(" +  config.DBServer + ")/" + which + "?charset=utf8")
}

func NewSQL() *SQL {
	var err error

	s := new(SQL)

	s.db, err = opendb(config.DBDatabase)
	if err != nil {
		log.Fatalf("could not connect to database: %v", err)
	}

	s.getconsoles, err = s.db.Prepare(
		`SELECT cat_title
			FROM wiki_category
			WHERE cat_title LIKE "%games"
				AND cat_pages > 0
			ORDER BY cat_title ASC;`)
	if err != nil {
		log.Fatalf("could not prepare console list query: %v", err)
	}

	s.getgames, err = s.db.Prepare(
		`SELECT wiki_page.page_title
			FROM wiki_page, wiki_categorylinks
			WHERE wiki_categorylinks.cl_to = ?
				AND wiki_page.page_id = wiki_categorylinks.cl_from
				AND wiki_page.page_namespace = 0
			ORDER BY wiki_page.page_title ASC;`)
	if err != nil {
		log.Fatalf("could not prepare game list query: %v", err)
	}

	s.getredirect, err = s.db.Prepare(
		`SELECT wiki_redirect.rd_title
			FROM wiki_redirect, wiki_page
			WHERE wiki_page.page_title = ?
				AND wiki_page.page_id = wiki_redirect.rd_from
				AND wiki_redirect.rd_interwiki = "";`)	// don't cross sites
	if err != nil {
		log.Fatalf("could not prepare redirect query (for scan list): %v", err)
	}

	s.getcatlist, err = s.db.Prepare(
		`SELECT wiki_categorylinks.cl_to
			FROM wiki_page, wiki_categorylinks
			WHERE wiki_page.page_namespace = 6
				AND wiki_page.page_title = ?
				AND wiki_categorylinks.cl_from = wiki_page.page_id;`)
	if err != nil {
		log.Fatalf("could not prepare category list query (for checking a scan): %v", err)
	}

	s.db_scanbox, err = opendb(config.DBScanboxDatabase)
	if err != nil {
		log.Fatalf("could not connect to scanbox database: %v", err)
	}

// TODO when sqlx adds sqlx.Stmt.Queryx() I can uncomment this
//	s.getscanboxes, err = s.db_scanbox.Preparex(
//	s.getscanboxes = (
//		`SELECT *
//			FROM Scanbox
//			WHERE _page = ?;`)
//	if err != nil {
//		log.Fatalf("could not prepare scanbox list query: %v", err)
//	}
// TODO and sqlx doesn't seem to fill in the structure properly?

	s.getscanboxes, err = s.db_scanbox.Prepare(
		`SELECT console, region, cover, front, back, spine, spinemissing,square, spinecard, cart, disc, disk, manual, jewelcase, jewelcasefront, jewelcaseback, jewelcasespine, jewelcasespinemissing, item1, item2, item3, item4, item5, item6, item7, item8, item1name, item2name, item3name, item4name, item5name, item6name, item7name, item8name, spine2, top, bottom
			FROM Scanbox
			WHERE _page = ?;`)
	if err != nil {
		log.Fatalf("could not prepare scanbox list query: %v", err)
	}

	s.getnoscans, err = s.db_scanbox.Prepare(
		`SELECT console
			FROM NoScans
			WHERE _page = ?;`)
	if err != nil {
		log.Fatalf("could not prepare noscans list query: %v", err)
	}

	return s
}

func init() {
	addInit(func() {
		globsql = NewSQL()
	})
}

func canonicalize(pageName string) string {
	pageName = strings.Replace(pageName, " ", "_", -1)
	k := []rune(pageName)		// force first letter uppercase
	k[0] = unicode.ToUpper(k[0])
	return string(k)
}

func sql_getconsoles(filter func(string) bool) ([]string, error) {
	return globsql.GetConsoleList(filter)
}

func (s *SQL) GetConsoleList(filter func(string) bool) ([]string, error) {
	var consoles []string

	gl, err := s.getconsoles.Query()
	if err != nil {
		return nil, fmt.Errorf("could not run console list query: %v", err)
	}
	defer gl.Close()

	for gl.Next() {
		var b []byte

		err = gl.Scan(&b)
		if err != nil {
			return nil, fmt.Errorf("error reading entry in console list query: %v", err)
		}
		// TODO save the string conversion for later? or do we even need to convert to string...?
		c := string(b)
		// make human readable and drop _games
		c = strings.Replace(c, "_", " ", -1)
		c = c[:len(c) - len(" games")]
		if filter(c) {
			consoles = append(consoles, c)
		}
	}
	sort.Strings(consoles)
	return consoles, nil
}

func sql_getgames(console string) ([]string, error) {
	return globsql.GetGameList(console)
}

func (s *SQL) GetGameList(console string) ([]string, error) {
	var games []string

	gl, err := s.getgames.Query(canonicalize(console))
	if err != nil {
		return nil, fmt.Errorf("could not run game list query: %v", err)
	}
	defer gl.Close()

	// use sql.RawBytes to avoid a copy since we're going to be converting to string anyway
	// TODO or do we even need to convert to string...?
	var b sql.RawBytes

	for gl.Next() {
		err = gl.Scan(&b)
		if err != nil {
			return nil, fmt.Errorf("error reading entry in game list query: %v", err)
		}
		games = append(games, string(b))
	}
	return games, nil
}

func sql_getscanboxes(page string, console string) ([]Scan, bool, error) {
	return globsql.GetScanboxes(page, console)
}

// get scanboxes, following all redirects
// TODO use []*Scan to reduce memory copies?
func (s *SQL) GetScanboxes(page string, console string) ([]Scan, bool, error) {
	var nextTitle []byte			// this should be sql.RawBytes but apparently I can't do that with sql.Stmt.QueryRow()

	curTitle := canonicalize(page)
	for {
		err := s.getredirect.QueryRow(curTitle).Scan(&nextTitle)
		if err == sql.ErrNoRows {			// no redirect, so finished
			break
		} else if err != nil {
			return nil, false, fmt.Errorf("error running or reading entry in redirect result rows query (for scan list): %v", err)
		}
		// TODO do we even need to convert to string...?
		curTitle = string(nextTitle)		// not finished; follow redirect
	}

	// does it have no scans?
	noscans, err := s.getnoscans.Query(curTitle)
	if err != nil {
		return nil, false, fmt.Errorf("could not run noscans list query (for scan list): %v", err)
	}
	defer noscans.Close()

	for noscans.Next() {
		var c string

		err := noscans.Scan(&c)
		if err != nil {
			return nil, false, fmt.Errorf("error reading entry in noscans list query (for scan list): %v", err)
		}
		if strings.EqualFold(console, c) {
			return nil, true, nil		// no scans
		}
	}

	// now we just get all the scanboxes
	scanboxes := make([]Scan, 0)
// TODO uncomment this when sqlx adds sqlx.Stmt.Queryx
//	sbl, err := s.getscanboxes.Queryx(curTitle)
curTitle = "AWS Pro Moves Soccer"
	sbl, err := s.getscanboxes.Query(curTitle)
	if err != nil {
		return nil, false, fmt.Errorf("could not run scanbox list query (for scan list): %v", err)
	}
	defer sbl.Close()

	for sbl.Next() {
		var s Scan

//		err := sbl.StructScan(&s)
		err := sbl.Scan(
			&s.Console,
			&s.Region,
			&s.Cover,
			&s.Front,
			&s.Back,
			&s.Spine,
			&s.DBSpineMissing,
			&s.DBSquare,
			&s.SpineCard,
			&s.Cart,
			&s.Disc,
			&s.Disk,
			&s.Manual,
			&s.JewelCase,
			&s.JewelCaseFront,
			&s.JewelCaseBack,
			&s.JewelCaseSpine,
			&s.DBJCSM,
			&s.Item1,
			&s.Item2,
			&s.Item3,
			&s.Item4,
			&s.Item5,
			&s.Item6,
			&s.Item7,
			&s.Item8,
			&s.Item1name,
			&s.Item2name,
			&s.Item3name,
			&s.Item4name,
			&s.Item5name,
			&s.Item6name,
			&s.Item7name,
			&s.Item8name,
			&s.Spine2,
			&s.Top,
			&s.Bottom)
		if err != nil {
			return nil, false, fmt.Errorf("error reading entry in scanbox list query (for scan list): %v", err)
		}
		scanboxes = append(scanboxes, s)
	}

	return scanboxes, false, nil
}

func isfileincategorywithprefix(file string, prefix []byte) (bool, error) {
	return globsql.IsFileInCategoryWithPrefix(file, prefix)
}

func (s *SQL) IsFileInCategoryWithPrefix(file string, prefix []byte) (bool, error) {
	cl, err := s.getcatlist.Query(canonicalize(file))
	if err != nil {
		return false, fmt.Errorf("could not run category list query (for checking a scan): %v", err)
	}
	defer cl.Close()

	// use sql.RawBytes to avoid a copy since we aren't storing the bytes, only checking against them
	var b sql.RawBytes

	for cl.Next() {
		err = cl.Scan(&b)
		if err != nil {
			return false, fmt.Errorf("error reading entry in category list query (for checking a scan): %v", err)
		}
		if bytes.HasPrefix(b, prefix) {
			return true, nil
		}
	}
	return false, nil			// nope
}
